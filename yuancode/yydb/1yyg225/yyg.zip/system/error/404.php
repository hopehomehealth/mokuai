<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title><?php echo $heading; ?></title>
<style type="text/css">
*{ padding: 0; margin: 0;}
body{ text-align: center; padding-top:20px; }
</style>
</head>
<body class="error_body">
    <a href="/"><img src="/style/images/error/404.png" /></a>
    <script type="text/javascript">
        setTimeout(function(){ location.href='/' },5000);
    </script>
</body>
</html>