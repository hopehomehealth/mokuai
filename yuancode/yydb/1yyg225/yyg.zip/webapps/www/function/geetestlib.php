<?php
/**
 * 极验行为式验证安全平台，php 网站主后台包含的库文件
 */
function geetest_validate($challenge, $validate, $seccode) {
	$apiserver = 'api.geetest.com';
	if (strlen($validate) > 0 && _check_result_by_private($challenge, $validate)) {		
		$query = 'seccode='.$seccode;
		$servervalidate = _http_post($apiserver, '/validate.php', $query);			
		if (strlen($servervalidate) > 0 && $servervalidate == md5($seccode)) {
			return TRUE;
		}
	}
	
	return FALSE;		
}

function _check_result_by_private($origin, $validate) {
	return $validate == md5(PRIVATE_KEY_CODE.'geetest'.$origin) ? TRUE : FALSE;
}

function _http_post($host, $path, $data, $port = 80) {
	// $data = _fix_encoding($data);
	
	$http_request  = "POST $path HTTP/1.0\r\n";
	$http_request .= "Host: $host\r\n";
	$http_request .= "Content-Type: application/x-www-form-urlencoded\r\n";
	$http_request .= "Content-Length: " . strlen($data) . "\r\n";
	$http_request .= "\r\n";
	$http_request .= $data;

	$response = '';
	if (($fs = @fsockopen($host, $port, $errno, $errstr, 10)) == false) {
		die ('Could not open socket! ' . $errstr);
	}
	
	fwrite($fs, $http_request);

	while (!feof($fs))
		$response .= fgets($fs, 1160);
	fclose($fs);
	
	$response = explode("\r\n\r\n", $response, 2);
	return $response[1];
}

function _fix_encoding($str) { 	
	$curr_encoding = mb_detect_encoding($str) ; 
	
	if($curr_encoding == "UTF-8" && mb_check_encoding($str,"UTF-8")) {
		return $str; 
	} else {
		return utf8_encode($str); 
	}
}

?>