<?php

/**
 * Class log_model
 */
class log_model extends Lowxp_Model{

    public $logTable = '###_m_user_log';
    public $smslogTable = '###_verify_code';


}