<?php
#商户编号p1_MerId,以及密钥merchantKey 需要从易宝支付平台获得
$p1_MerId	 = "10012425252";
$merchantKey = "wN3zQdCg078dP9cM376v1fP68199867Q1c186oZgX8Xw933i6V41748gs4m4";
$p0_Cmd      = "Buy";
$p9_SAF      = "0";
$reqURL_onLine = "https://www.yeepay.com/app-merchant-proxy/node";
$logName	 = "YeePay_HTML.log";
?>