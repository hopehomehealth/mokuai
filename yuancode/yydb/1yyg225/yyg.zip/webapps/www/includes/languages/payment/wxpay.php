<?php

global $_LANG;

$_LANG['wxpay'] = '微信端支付';
$_LANG['wxpay_desc'] = '微信支付';
$_LANG['wxpay_app_id'] = 'app_id';
$_LANG['wxpay_app_secret'] = 'app_secret';
$_LANG['wxpay_mchid'] = 'mchid';
$_LANG['wxpay_key'] = 'key';
$_LANG['notifyurl'] = 'notifyurl';
$_LANG['successurl'] = 'successurl';
$_LANG['pay_button'] = '立即使用微信支付';
?>