<?php
global $_LANG;
$_LANG['jubaopay'] = '聚宝付';
$_LANG['jubaopay_desc'] = "APP支付接口<a href='http://www.jubaopay.com/' target='_blank'>申请地址</a>";
$_LANG['appid'] = '商户号';
$_LANG['psw'] = '静态密码';
?>