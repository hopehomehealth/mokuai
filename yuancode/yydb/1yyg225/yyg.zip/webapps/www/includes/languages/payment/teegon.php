<?php
global $_LANG;
$_LANG['teegon'] = '天工支付';
$_LANG['teegon_desc'] = "APP支付接口<a href='https://charging.teegon.com/' target='_blank'>申请地址</a>";
$_LANG['TEE_CLIENT_ID'] = '商户号';
$_LANG['TEE_CLIENT_SECRET'] = '静态密码';
?>