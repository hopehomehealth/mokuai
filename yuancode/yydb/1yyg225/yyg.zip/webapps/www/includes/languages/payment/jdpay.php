<?php
global $_LANG;
$_LANG['jdpay'] = '京东支付';
$_LANG['jdpay_desc'] = "京东支付";
$_LANG['app_id'] = '商户开通的商户号';
$_LANG['app_key'] = '商户DES密钥';
