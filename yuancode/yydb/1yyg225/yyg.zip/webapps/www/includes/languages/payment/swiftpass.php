<?php
global $_LANG;
$_LANG['swiftpass'] = '威富通支付';
$_LANG['swiftpass_desc'] = '威富通支付 支付接口';
$_LANG['app_id'] = '商户编号';
$_LANG['app_key'] = '商家签名';
