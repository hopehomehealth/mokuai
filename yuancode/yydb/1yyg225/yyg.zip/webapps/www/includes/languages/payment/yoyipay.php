<?php
global $_LANG;
$_LANG['yoyipay'] = '甬易支付';
$_LANG['yoyipay_desc'] = '支付接口';
$_LANG['app_id'] = '商户编号';
$_LANG['app_key'] = '商家密钥';
$_LANG['app_preprocess'] = '支付网关URL';
$_LANG['app_query'] = '订单查询URL';
