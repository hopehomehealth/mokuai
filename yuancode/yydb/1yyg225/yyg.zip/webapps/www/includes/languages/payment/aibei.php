<?php
global $_LANG;
$_LANG['aibei'] = '爱贝支付';
$_LANG['aibei_desc'] = "APP支付接口<a href='https://www.iapppay.com/home.html' target='_blank'>申请地址</a>";
$_LANG['appid'] = '应用编号';
$_LANG['appkey'] = '应用私钥';
$_LANG['platpkey'] = '平台公钥';
?>