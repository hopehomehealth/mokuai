<?php

global $_LANG;

$_LANG['wxpayapp'] = '微信APP支付';
$_LANG['wxpayapp_desc'] = 'APP支付接口 <a target="_blank" href="https://open.weixin.qq.com/cgi-bin/frame?t=home/app_tmpl&lang=zh_CN">立即申请</a>';
$_LANG['wxpay_app_id'] = 'APPID';
$_LANG['wxpay_mchid'] = 'MCHID';
$_LANG['wxpay_app_secret'] = 'APPSECRET';
$_LANG['wxpay_key'] = 'KET';
?>