<?php
global $_LANG;
$_LANG['ipaynow'] = '现在支付';
$_LANG['ipaynow_desc'] = 'APP支付接口';
$_LANG['app_id'] = '应用编号';
$_LANG['secure_key'] = '应用密钥';
?>