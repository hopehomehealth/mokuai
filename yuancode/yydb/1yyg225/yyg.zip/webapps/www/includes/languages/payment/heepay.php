<?php
global $_LANG;
$_LANG['heepay'] = '汇付宝网银支付';
$_LANG['heepay_desc'] = '汇付宝网银支付 支付接口';
$_LANG['app_id'] = '商户编号';
$_LANG['app_key'] = '商家签名';
