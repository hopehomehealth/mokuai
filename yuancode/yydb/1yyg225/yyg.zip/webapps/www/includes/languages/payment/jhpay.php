<?php
global $_LANG;
$_LANG['jhpay'] = '聚合富';
$_LANG['jhpay_desc'] = '在线支付接口';
$_LANG['app_id'] = '商户编号';
$_LANG['app_key'] = 'MD5 Key';