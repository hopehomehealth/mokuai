<?php
/** 前端公共语言包 */
$L['msg_bad_data'] = '数据发送自未被信任的域名，如有疑问，请联系管理员';
$L['unit_yun'] = '云购';
$L['unit_yun_one'] = '一元云购';
$L['unit_yun_button'] = '立即云购';
$L['unit_db_points'] = '云购币';
$L['unit_pay_points'] = '拍币';
$L['unit_pay'] = '竞拍';
$L['unit_bonus'] = '红包';
$L['unit_baozheng'] = '保证金';
$L['unit_winning'] = '中奖';
$L['unit_price'] = '奖品';
$L['unit_gift'] = '注册有礼';
$L['unit_go_buy'] = '直购';
$L['unit_bonus_unit'] = '个';

$this->smarty->assign('L', $this->L=$L);
