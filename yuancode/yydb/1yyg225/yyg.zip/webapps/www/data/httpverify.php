<?php $data = array (
  'error' => 0,
  'error_text' => '',
  'time' => 1471951079,
); ?>