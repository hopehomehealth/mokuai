<?php $data = array (
  'ids' => ',',
  'list' => 
  array (
  ),
); ?>