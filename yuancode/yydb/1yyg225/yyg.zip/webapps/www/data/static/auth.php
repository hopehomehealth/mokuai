<?php $data = array (
  'auth' => '2ce1d02cf6a188ab45318cfd8725dd6e',
  'time' => 1471951081,
); ?>