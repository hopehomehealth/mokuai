<?php $data = array (
  'logCount' => '0',
); ?>