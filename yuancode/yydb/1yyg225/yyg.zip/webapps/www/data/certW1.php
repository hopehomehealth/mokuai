<?php
$certW1 = array(
    'priceLimit'=>'5000'/*0不限制 大于0为限制的价格,certW2可重置此值*/,
    '红包','现金','香烟'
);
?>