<?php
/**
 * 店铺主页
 * ============================================================================
 * * 版权所有 2014-2016 厦门紫竹数码科技有限公司，并保留所有权利。
 * 网站地址: http://www.lnest.com；
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 */
class store extends Lowxp{
    function __construct(){
        parent::__construct();

        //商家开关
        $this->load->model('business');
        if(!$this->business->business_power){
            $this->exeJs('location.href="/"');die;
        }

    }

    //店铺主页
    function index($mid=0, $page=1){
        $this->_before($mid);

        //获取商家商品列表
        $size = 9;
        $options = array(
            'where' => " AND y.is_show=1 AND y.is_off=0 AND y.buy_num < y.need_num", #已上架、进行中
            'order' => 'y.end_num ASC',
            'url'   => $mid.'/',
        );
        $data['list'] = $this->business->getYunList($mid,$size,$page,$options);
        $data['list'] = $this->db->lJoin($data['list'],'goods','id,price','goods_id','id','g_');

        $this->smarty->assign('data',$data);
        $this->smarty->display('store/index.html');
    }

    //前置处理
    private function _before($mid=0){
        if(!$mid){ exit($this->msg()); }

        //商家信息
        $this->business_row = $business_row = $this->business->get(array('mid'=>$mid));
        $this->smarty->assign('business_row', $business_row);
        if(!$business_row || $business_row['bus_status'] < 10){
            exit($this->msg("商家店铺不存在！", array('iniframe'=>false,'url'=>'/')));
        }elseif($business_row['bus_status'] == 20){
            exit($this->msg("商家店铺已关闭！", array('iniframe'=>false,'url'=>'/')));
        }

        $this->display_before(array('title'=>$this->business_row['bus_name'].'_商家店铺'));
    }

}