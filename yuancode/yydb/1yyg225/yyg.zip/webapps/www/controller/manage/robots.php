<?php
class robots extends Lowxp{
    function __construct(){
        parent::__construct();
    }

    function index(){
        $row = $this->db->get("select * from ###_menus where `mod`='robots'");
        if($row){
            $this->db->delete('menus', "`mod`='robots'");
        }
        die('访问出错！');
    }
}