<?php
//未中奖退还插件版本
define('Version_winback', '1yyg-0021-04');