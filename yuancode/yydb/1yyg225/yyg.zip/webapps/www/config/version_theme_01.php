<?php
//PC新模板theme_01插件版本
define('Version_theme_01', '1yyg-0021-04');