<?php
if(IS_DEV){ //本地
    $config['host'] = '127.0.0.1';
    $config['user'] = 'root';
    $config['pass'] = 'Hh5669270';
    $config['dbname'] = '1yyg225';
    $config['pre'] = 'zz_';
}else{ //服务器
    $config['host'] = '106.14.43.82';
    $config['user'] = 'root';
    $config['pass'] = 'Hh5669270';
    $config['dbname'] = '1yyg225';
    $config['pre'] = 'zz_';
}