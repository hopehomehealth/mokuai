<?php
//众筹插件版本
define('Version_crowd', '1yyg-0021-04');