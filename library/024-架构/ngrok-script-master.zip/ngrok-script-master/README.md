# ngrok-script
A script to run local ngrok client for linux and windows

This ngrok server is using http://ngrok.2bdata.com which is totally free.

## Usage

windows:

```
ngrok.bat domain
```

linux or mac:

```
./ngrok.sh domain
```

Then ngrok will run as domain `domain.tunnel.2bdata.com`

<img src="https://ws2.sinaimg.cn/large/685b97a1gy1fe9lpwosldj20hy04ldfx.jpg">
